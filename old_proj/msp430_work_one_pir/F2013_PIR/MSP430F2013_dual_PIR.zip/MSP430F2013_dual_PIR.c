//*****************************************************************************
//  Code for - "Dual Ultra-low Power Motion Detection
//    using the MSP430F2013"
//
//  Version 2-00
//
//  Version Summary:
//  1-00 released 12-22-2014- Initial release
//  2-00 released 9-24-2015- digital low pass filter
//
//  6-00 released 8-28-2019- 8/13 experimental results to find the dividend 2048
//                           8/27 Propose how to find the eigenvalues of the waveform
//                           8/28 Using DAC to generate signals, testing 5000 times, can correctly capture the eigenvalues
//  7-00 released 9-6-2019-  9/6  For the additional processing of the eigenvalue 0X02, it will be triggered 3 to 5 times in 20 minutes
//  8-00 released 9-23-2019- 9/23 for dual PIR
//  8-10 released 11-26-2019- 11/26 for dual PIR voltage detector
//  Built with IAR Embedded Workbench Version: 5.20
//*****************************************************************************

#include  <msp430x20x3.h>
#define   WDT_PIN          BIT7                // P2.7 Watch Dog Timer 
#define   RDY_PIN          BIT7                 // P1.7 Watch Dog Timer
//#define   SPICS_PIN        BIT4                // P1.4 SPI CS
#define   LED_OUT          BIT0                // P1.0 =>Bit location for LED
//#define   LED2_OUT         BIT6                // P1.6 =>Bit location for LED2
#define   RELAY_ON         BIT6                // P2.6
#define   fWvERSION           7                // firm ware VERSION
#define   iLEDtIME        42000                // V3:31250 iNITION LED tIME 250ms flash one time
#define   iLEDcYCLE         140                //140 for 30sec, 40 for 10sec, Wait sensor stable
#define   wDTtIMEoUT         10                //10x50ms=0.5S
#define   tRIGtIMEoUT       80                //100x50ms=5.0S //100
#define   aDCtIMEoUT          5                //5*200ms=1.0S //2
#define   HIGH_               1
#define   LOW_                0
#define   oRtRUE              1
#define   aNDfALSE        65534
#define   pULSEwIDTH          1                //default 3, wavefrom width
#define   cHAR_0x02_tRIG      3                //default 3
#define   cHAR_0x02_xhOUR  2850                //cHAR_0x02_tIMES times trigger, 2min=285, 20min=2850
#define   vOLTAGE_dET_L   41819                //9.0V - 0.5V
#define   vOLTAGE_dET_H   43190                //9.0V + 0.5V

#define   mODE12V             0                //12V
#define   mODE09V             1                //9V

extern unsigned char  WDT_Count = 0;
extern unsigned char  TRIGGER_Count = 0;

extern unsigned char  ADC1_TRIGGER_Count = tRIGtIMEoUT;
extern unsigned char  ADC_TRIGGER_Count = tRIGtIMEoUT;
extern unsigned char  ADC_Delay_Count = 0;

extern unsigned int Result_old = 50000;      // Storage for last conversion
extern unsigned int Result2_old = 50000;     // Storage for last conversion
extern unsigned int Result3_old = 50000;     // Storage for last conversion
unsigned int ADCANY = 0;                // adc/2^9
unsigned int ADCANY2= 0;                // adc/2^9
unsigned int ADCANY3 = 0;               // adc/2^9
unsigned int NORMAL_ADCANY = 64;          // adc/2^9
unsigned int NORMAL_ADCANY2= 64;          // adc/2^9
unsigned int NORMAL_ADCANY_LLIMIT = 60;   // adc/2^9
unsigned int NORMAL_ADCANY_HLIMIT = 68;   // adc/2^9
unsigned int NORMAL_ADCANY_LLIMIT2= 60;   // adc/2^9
unsigned int NORMAL_ADCANY_HLIMIT2= 68;   // adc/2^9
unsigned char CHAR_ADCANY = 0;          // Eigenvalues, wavefrom -u-/-n-=0x02; -un-/-nu-=0x04; -unu-/-nun-=0x06....
unsigned char CHAR_ADCANY2= 0;          // Eigenvalues, wavefrom -u-/-n-=0x02; -un-/-nu-=0x04; -unu-/-nun-=0x06....
unsigned char byteTemp = 0;             // Storage for last conversion
unsigned char flagADC = 0; 
unsigned char flagADC2= 0; 
unsigned char flagHighLevel1= 1; 
unsigned char flagHighLevel2= 1;
unsigned char counterADC = 1; 
unsigned char timeOutADC = 0; 
unsigned char timeOutADC2= 0; 
unsigned char timeOutMode09V= 0; 
unsigned char timeOutMode12V= 0; 
unsigned char pulseWidthCNT = 0;
unsigned char pulseWidthCNT2= 0;
unsigned char CHAR_0x02_CNT = 0;      // Eigenvalues=0x02 -u-/-n-, counter
unsigned char CHAR_0x02_CNT2= 0;      // Eigenvalues=0x02 -u-/-n-, counter
unsigned int  CHAR_0x02_TIME = cHAR_0x02_xhOUR; // time<=cHAR_0x02_xhOUR, CHAR_0x02_CNT>=cHAR_0x02_tIMES ,trigger, timeout reset
unsigned int  CHAR_0x02_TIME2= cHAR_0x02_xhOUR; // time<=cHAR_0x02_xhOUR, CHAR_0x02_CNT>=cHAR_0x02_tIMES ,trigger, timeout reset

unsigned char modeState= 0; 

void main(void)

{
  unsigned int init_led_onoff_time = 0;
  unsigned int init_led_onoff_cycle = 0;
  
  WDTCTL = WDTPW+WDTTMSEL+WDTCNTCL+WDTSSEL;    // ACLK/32768, int timer: ~10s
  BCSCTL1 = CALBC1_1MHZ;                       // Set DCO to 1MHz
  DCOCTL = CALDCO_1MHZ;
  BCSCTL1 |= DIVA_2;                           // ACLK = VLO/4(default)
  BCSCTL3 |= LFXT1S_2;

  P1SEL = 0x08;                                // Select VREF function
  //P2DIR = 0xFF;
  
  //LED_OUT
  P1DIR |= LED_OUT;  P1SEL &= ~LED_OUT;  P1OUT |= LED_OUT;  P1REN &= ~LED_OUT; 
  //RDY_PIN
  P1DIR |= RDY_PIN;  P1SEL &= ~RDY_PIN;  P1OUT |= RDY_PIN;  P1REN &= ~RDY_PIN;
  //WDT_PIN
  P2DIR |= WDT_PIN;  P2SEL &= ~WDT_PIN;  P2OUT |= WDT_PIN;  P2REN &= ~WDT_PIN;
  //RELAY_ON, trigger loop close/open, RELAY_ON=1/open, RELAY_ON=0/close
  P2DIR |= RELAY_ON;  P2SEL &= ~RELAY_ON;  P2OUT |= RELAY_ON;  P2REN &= ~RELAY_ON;
  
  SD16CTL = SD16VMIDON + SD16REFON + SD16SSEL_2;   // 1.2V ref with buffer out(P1.3), clock=ACLK(SD16SSEL_2)
  SD16CCTL0 =  SD16SNGL + SD16IE + SD16OSR_32; // Single conversion, 32OSR, Int enable
  SD16INCTL0 = SD16GAIN_1 + SD16INCH_4;            // PGA = 1, Diff inputs A4- & A4+  
  //SD16AE = SD16AE1 + SD16AE2 + SD16AE4 + SD16AE5 + SD16AE6;
  SD16AE = SD16AE1 + SD16AE4 + SD16AE6;
  SD16CTL &= ~SD16REFON;                    // Turn off SD16_A ref
  
  //power on or reset run delay 2xSec
  
  for(init_led_onoff_cycle=0;init_led_onoff_cycle <=iLEDcYCLE;init_led_onoff_cycle++)
  {
    P2OUT ^= WDT_PIN;
    for(init_led_onoff_time=0;init_led_onoff_time <=iLEDtIME;init_led_onoff_time++)
    {}
    if(((fWvERSION*2-2)<= init_led_onoff_cycle) && (init_led_onoff_cycle <= 16))
    {
          
    }
    else
    {
     P1OUT ^= LED_OUT;
    }
  }  
  
  // turn off LED
  //P1OUT &= ~LED_OUT;
  
  // setup PIN YDU_PIN to input,
  P1REN |= RDY_PIN; P1DIR &= ~RDY_PIN; P1SEL |= RDY_PIN; P1OUT &= ~RDY_PIN;
  
  //SD16CCTL0 =  SD16SNGL + SD16IE + SD16OSR_32; // Single conversion, 32OSR, Int enable
  BCSCTL1 |= DIVA_1;                           // DIVA_1=>ACLK = VLO/2
  
  WDTCTL = WDTPW+WDTTMSEL+WDTCNTCL+WDTSSEL+WDTIS1+WDTIS0;  //11:ACLK/64 10:ACLK/512 TimeBase=47.2mS
  IE1 |= WDTIE;                                // Enable WDT interrupt
  
  counterADC = 1;
  ADC_TRIGGER_Count=tRIGtIMEoUT; ADC1_TRIGGER_Count=tRIGtIMEoUT;
  modeState=mODE12V;
  //SD16CTL |= SD16REFON;                        // If no(no got motion signal), turn on SD16_A ref
  //SD16CCTL0 |= SD16SC;                         // Set bit to start new conversion
  ADC_Delay_Count=0;
  //_BIS_SR(LPM3_bits + GIE);                 // Enter LPM3 with interrupts
  
  while (1)
  {
    __bis_SR_register(CPUOFF + GIE);   // Enter LPM0 w/ interrupts
                                       // Remain in LPM0 until all data is received
  }
}

/******************************************************
// SD16_A interrupt service routine
******************************************************/
#pragma vector = SD16_VECTOR
__interrupt void SD16ISR(void)
{   
  SD16CTL &= ~SD16REFON;                    // Turn off SD16_A ref
  switch(counterADC)
  {
  case 1:
    Result_old = SD16MEM0;                    // Save result (clears IFG)
    if (modeState==mODE12V)
    {
    ADCANY=Result_old>>9;
    NORMAL_ADCANY_LLIMIT = NORMAL_ADCANY-3;
    NORMAL_ADCANY_HLIMIT = NORMAL_ADCANY+3;  
    /*
    if(ADCANY <= NORMAL_ADCANY_LLIMIT)
    {
      P1OUT ^= LED_OUT;
      if(flagADC) {}
      else { flagADC=HIGH_; timeOutADC=0; }
      pulseWidthCNT++; CHAR_ADCANY=CHAR_ADCANY|oRtRUE;
    }
    */
    if (ADCANY >= NORMAL_ADCANY_HLIMIT)
    {
      P1OUT ^= LED_OUT;
      if(flagADC) {}
      else { flagADC=HIGH_; timeOutADC=0; }
      pulseWidthCNT++; CHAR_ADCANY=CHAR_ADCANY|oRtRUE;
    } 
    
    timeOutADC++; 
    
    //if ((ADCANY==NORMAL_ADCANY)&&(flagADC==HIGH_))
    if (((ADCANY>=NORMAL_ADCANY-2)&&(ADCANY<=NORMAL_ADCANY+2))&&(flagADC==HIGH_))
    {
      if(pulseWidthCNT>=pULSEwIDTH) { CHAR_ADCANY=CHAR_ADCANY+1; }
      pulseWidthCNT=0;
    }
    
    if (timeOutADC>=aDCtIMEoUT)
    {
      flagADC=LOW_; timeOutADC=aDCtIMEoUT; NORMAL_ADCANY=(ADCANY+NORMAL_ADCANY)/2;    
      //if((CHAR_ADCANY>=0x02)&&(ADC_TRIGGER_Count>=tRIGtIMEoUT)) { ADC_TRIGGER_Count=0; CHAR_0x02_CNT=0; CHAR_0x02_TIME=cHAR_0x02_xhOUR; }
      if(CHAR_ADCANY>=0x01) { ADC_TRIGGER_Count=0; CHAR_0x02_CNT=0; CHAR_0x02_TIME=cHAR_0x02_xhOUR; }
      CHAR_ADCANY=0;
    }
    }
    SD16INCTL0 &= ~SD16INCH_4;          // Disable channel A4+/-
    counterADC=2;
    SD16INCTL0 |= SD16INCH_3;           // Enable channel A3+
    //SD16CTL |= SD16REFON;                   // If no(no got motion signal), turn on SD16_A ref
    //SD16CCTL0 |= SD16SC;                    // Set bit to start new conversion
    ADC_Delay_Count=0;
    //__bis_SR_register_on_exit(SCG1+SCG0);     // Return to LPM3 after reti
    break;
  
  case 0:
    Result2_old = SD16MEM0;                    // Save result (clears IFG)
    if (modeState==mODE12V)
    {
    ADCANY2=Result2_old>>9;
    NORMAL_ADCANY_LLIMIT2 = NORMAL_ADCANY2-3;
    NORMAL_ADCANY_HLIMIT2 = NORMAL_ADCANY2+3;  
    /*
    if(ADCANY2 <= NORMAL_ADCANY_LLIMIT2)
    {
      if(flagADC2) {}
      else { flagADC2=HIGH_; timeOutADC2=0; }
      pulseWidthCNT2++; CHAR_ADCANY2=CHAR_ADCANY2|oRtRUE;
    }
    */
    //if (ADCANY2 >= NORMAL_ADCANY_HLIMIT2-2) { P1OUT ^= LED_OUT; }
    
    if (ADCANY2 >= NORMAL_ADCANY_HLIMIT2)
    {
      if(flagADC2) {}
      else { flagADC2=HIGH_; timeOutADC2=0; }
      pulseWidthCNT2++; CHAR_ADCANY2=CHAR_ADCANY2|oRtRUE;
    } 
    
    timeOutADC2++; 
    
    //if ((ADCANY2==NORMAL_ADCANY2)&&(flagADC2==HIGH_))
    if (((ADCANY2>=NORMAL_ADCANY2-2)&&(ADCANY2<=NORMAL_ADCANY2+2))&&(flagADC2==HIGH_))
    {
      if(pulseWidthCNT2>=pULSEwIDTH) { CHAR_ADCANY2=CHAR_ADCANY2+1; P1OUT ^= LED_OUT; }
      pulseWidthCNT2=0;
    }
    
    if (timeOutADC2>=aDCtIMEoUT)
    {
      flagADC2=LOW_; timeOutADC2=aDCtIMEoUT; NORMAL_ADCANY2=(ADCANY2+NORMAL_ADCANY2)/2;    
      if(CHAR_ADCANY2>=0x01) { ADC1_TRIGGER_Count=0; CHAR_0x02_CNT2=0; CHAR_0x02_TIME2=cHAR_0x02_xhOUR; }
      CHAR_ADCANY2=0;
    }
    }
    SD16INCTL0 &= ~SD16INCH_2;          // Disable channel A2+/-
    counterADC=1;
    SD16INCTL0 |= SD16INCH_4;           // Enable channel A4+/- 
    //SD16CTL |= SD16REFON;                   // If no(no got motion signal), turn on SD16_A ref
    //SD16CCTL0 |= SD16SC;                    // Set bit to start new conversion
    ADC_Delay_Count=0;
    //__bis_SR_register_on_exit(SCG1+SCG0);     // Return to LPM3 after reti  
    break;
  
  case 2:
    ADCANY3 = SD16MEM0;
    counterADC=0;
    if((ADCANY3<=vOLTAGE_dET_H)&&(Result3_old>=vOLTAGE_dET_L))
    {
      modeState=mODE09V;
    }
    else
    {
      modeState=mODE12V;
    }
    Result3_old=ADCANY3;
    SD16INCTL0 &= ~SD16INCH_3;              // Disable channel A3+
    SD16INCTL0 |= SD16INCH_2;               // Enable channel A4+/- 
    //SD16CTL |= SD16REFON;                   // If no(no got motion signal), turn on SD16_A ref
    //SD16CCTL0 |= SD16SC;                    // Set bit to start new conversion
    ADC_Delay_Count=0;
    //__bis_SR_register_on_exit(SCG1+SCG0);   // Return to LPM3 after reti 
    break;
  }
  //__bis_SR_register_on_exit(SCG1+SCG0);   // Return to LPM3 after reti
  __bic_SR_register_on_exit(CPUOFF);     // Return to LPM3 after reti
}

/******************************************************
// Watchdog Timer interrupt service routine
******************************************************/
#pragma vector=WDT_VECTOR
__interrupt void watchdog_timer(void)

{
  WDTCTL = WDTPW+WDTTMSEL+WDTCNTCL+WDTSSEL+WDTIS1+WDTIS0;
  P2OUT &= ~WDT_PIN;
  WDT_Count ++; 
  if (modeState==mODE12V)
  {
    TRIGGER_Count++;
    ADC_TRIGGER_Count++;
    ADC1_TRIGGER_Count++;  
    ADC_Delay_Count++;
    
    if(ADC_Delay_Count>=10)  { ADC_TRIGGER_Count=10; }
    if(ADC_Delay_Count==9)  
    { 
    SD16CTL |= SD16REFON;                   // If no(no got motion signal), turn on SD16_A ref
    SD16CCTL0 |= SD16SC;                    // Set bit to start new conversion
    __bic_SR_register_on_exit(CPUOFF);     // Return to LPM3 after reti
    }
    
    if(ADC_TRIGGER_Count>=tRIGtIMEoUT)  { ADC_TRIGGER_Count=tRIGtIMEoUT; }
    
    if(ADC1_TRIGGER_Count>=tRIGtIMEoUT) { ADC1_TRIGGER_Count=tRIGtIMEoUT; }
    
    //if((ADC_TRIGGER_Count<tRIGtIMEoUT)&&(ADC1_TRIGGER_Count<tRIGtIMEoUT))
    //if(((30<ADC_TRIGGER_Count)&&(3>ADC1_TRIGGER_Count))||((3>ADC_TRIGGER_Count)&&(30<ADC1_TRIGGER_Count)))
    //if(((ADC_TRIGGER_Count-ADC1_TRIGGER_Count)==5)||((ADC1_TRIGGER_Count-ADC_TRIGGER_Count)==5))
    {
      if((ADC_TRIGGER_Count<tRIGtIMEoUT)&&(ADC1_TRIGGER_Count<tRIGtIMEoUT))
      {
        //if(CHAR_ADCANY2==CHAR_ADCANY)
        {
        P2OUT |= RELAY_ON; TRIGGER_Count=0;
        }
        ADC_TRIGGER_Count=tRIGtIMEoUT; ADC1_TRIGGER_Count=tRIGtIMEoUT;
        //CHAR_ADCANY2=0;CHAR_ADCANY=0;
        //P1OUT |= LED_OUT;
      }
    }
    
    if(TRIGGER_Count>=tRIGtIMEoUT) {  P2OUT |= RELAY_ON; TRIGGER_Count=tRIGtIMEoUT; }
  }
  
  if (modeState==mODE09V)
  {
    P1OUT &= ~LED_OUT; P2OUT |= RELAY_ON; TRIGGER_Count=tRIGtIMEoUT;
  }
  

  if(WDT_Count>=wDTtIMEoUT)
  {
     P2OUT |= WDT_PIN;  WDT_Count=0; 
     
     if (modeState==mODE12V)
     {
       timeOutMode12V++;
       if ((TRIGGER_Count<tRIGtIMEoUT)||(timeOutMode12V>=wDTtIMEoUT)) { P1OUT ^= LED_OUT; timeOutMode12V=0; }
       else { P1OUT &= ~LED_OUT; }
       //SD16CTL |= SD16REFON;                   // If no(no got motion signal), turn on SD16_A ref
       //SD16CCTL0 |= SD16SC;                    // Set bit to start new conversion
     }
     
     if (modeState==mODE09V)
     {
       timeOutMode09V++;
       if (timeOutMode09V>=wDTtIMEoUT) { timeOutMode09V=0; P1OUT |= LED_OUT; }
       else { P1OUT &= ~LED_OUT; }
     }
     //if(CHAR_0x02_TIME>=cHAR_0x02_xhOUR) { CHAR_0x02_TIME=cHAR_0x02_xhOUR; }
     //else { CHAR_0x02_TIME++; }
     //if(CHAR_0x02_TIME2>=cHAR_0x02_xhOUR) { CHAR_0x02_TIME2=cHAR_0x02_xhOUR; }
     //else { CHAR_0x02_TIME2++; }
  }
  
  __bis_SR_register_on_exit(CPUOFF);     // Return to LPM3 after reti
}

